#ifndef AIS_CHARSET_H
#define AIS_CHARSET_H

extern char ais_charset[64];

#endif
