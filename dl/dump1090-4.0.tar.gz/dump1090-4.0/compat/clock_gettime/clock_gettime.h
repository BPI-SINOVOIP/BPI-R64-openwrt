#ifndef CLOCK_GETTIME_H
#define CLOCK_GETTIME_H

int clock_gettime(clockid_t clk_id, struct timespec *tp);

#endif // CLOCK_GETTIME_H
