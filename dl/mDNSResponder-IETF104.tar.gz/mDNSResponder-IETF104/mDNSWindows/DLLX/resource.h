//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DLLX.rc
//
#define IDS_PROJNAME                    100
#define IDR_DLLX		                101
#define IDR_DNSSD                       102
#define IDR_DNSSDSERVICE                103
#define IDR_BROWSELISTENER              104
#define IDR_RESOLVELISTENER             105
#define IDR_TXTRECORD                   106
#define IDR_ENUMERATEDOMAINSLISTENER    107
#define IDR_REGISTERLISTENER            108
#define IDR_QUERYRECORDLISTENER         109
#define IDR_GETADDRINFOLISTENER         110
#define IDR_DNSSDRECORD                 111
#define IDR_REGISTERRECORDLISTENER      112
#define IDR_NATPORTMAPPINGLISTENER      113
#define IDR_DNSSDEVENTMANAGER           114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           115
#endif
#endif
