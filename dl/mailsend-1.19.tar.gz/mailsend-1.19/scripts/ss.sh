$ ./configure --target=mipsel-linux --host=mipsel-linux --build=i686-pc-linux-gnu
