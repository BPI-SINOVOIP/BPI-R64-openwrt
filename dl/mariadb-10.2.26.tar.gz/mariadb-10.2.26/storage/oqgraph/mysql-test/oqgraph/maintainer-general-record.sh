#!/bin/sh
# This is a maintainer generated file. Generated at Wednesday 5 February 22:26:12 CST 2014.
mysql-test/mysql-test-run --record oqgraph.general-MyISAM
mysql-test/mysql-test-run --record oqgraph.general-MEMORY
mysql-test/mysql-test-run --record oqgraph.general-Aria
mysql-test/mysql-test-run --record oqgraph.general-innodb
