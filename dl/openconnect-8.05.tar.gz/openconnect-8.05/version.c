const char *openconnect_version_str = "v8.05";
