// +build !linux

package fs
