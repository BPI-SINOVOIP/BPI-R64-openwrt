package configs

// All current tests are for Unix-specific functionality
