
NAME='carbon'
CFLAGS = []
LDFLAGS = []
LIBS = []

GCC_LIST = ['carbon']
